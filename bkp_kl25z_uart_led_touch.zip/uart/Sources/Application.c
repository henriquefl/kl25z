#include "Application.h"
#include "RxBuf.h"
#include "AS1.h"
//#include "mcg.h"

static UART_Desc deviceData;

//#define LED_VERMELHO   (1<<18)   // 1 para sa�da.
//#define LED_VERDE     (1<<19)
//#define ENTRADA        (1<<1)
//#define PIN_ENTRADA     (0<<1) // 0 para entrada.

static void SendChar(unsigned char ch, UART_Desc *desc) {
  desc->isSent = FALSE;  /* this will be set to 1 once the block has been sent */
  while(AS1_SendBlock(desc->handle, (LDD_TData*)&ch, 1)!=ERR_OK) {} /* Send char */
  while(!desc->isSent) {} /* wait until we get the green flag from the TX interrupt */
}

static void SendString(const unsigned char *str,  UART_Desc *desc) {
  while(*str!='\0') {
    SendChar(*str++, desc);
  }
}

static void Init(void) {
  /* initialize struct fields */
  deviceData.handle = AS1_Init(&deviceData);
  deviceData.isSent = FALSE;
  deviceData.rxChar = '\0';
  deviceData.rxPutFct = RxBuf_Put;
  /* set up to receive RX into input buffer */
  RxBuf_Init(); /* initialize RX buffer */
  /* Set up ReceiveBlock() with a single byte buffer. We will be called in OnBlockReceived() event. */
  while(AS1_ReceiveBlock(deviceData.handle, (LDD_TData *)&deviceData.rxChar, sizeof(deviceData.rxChar))!=ERR_OK) {} /* initial kick off for receiving data */

}

void APP_Run(void) {
    //int iClock;

    // Cristal Externo de 8MHz, Low Power Mode, Cristal, PRDIV = 4, VDIV = 24,
    //iClock = pll_init(8000000, LOW_POWER, CRYSTAL,4,24,MCGOUT);


    // Habilitar o Clock dos Ports que ser�o utilizados (PORTB E PORTE).
//    SIM_SCGC5 |= SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTE_MASK;
//
//
//    // Configura o PinMux dos Ports como GPIO.
//    PORTE_PCR1 = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK;
//    PORTB_PCR18 = PORT_PCR_MUX(1);
//     PORTB_PCR19 = PORT_PCR_MUX(1);
//
//
//     // Configura��o da Dire��o dos Ports.
//     GPIOE_PDDR &= PIN_ENTRADA;
//     GPIOB_PDDR |= LED_VERMELHO | LED_VERDE;
//
     Configure();
    for(;;)
    {
    	TSS_Task();
//      // Tecla est� pressionada?
      if(GPIOE_PDIR & ENTRADA)
      {
         // N�o, liga o LED Vermeho e desliga o Verde.
//         GPIOB_PSOR |= LED_VERDE;     // Desliga LED Verde.
//         GPIOB_PCOR |= LED_VERMELHO;     // Liga LED Vermelho.
      }
      else
      {
         // Sim, liga o LED Verde e desliga o Vermelho.
//         GPIOB_PSOR |= LED_VERMELHO;     // Desliga LED Vermelho.
//         GPIOB_PCOR |= LED_VERDE;     // Liga LED Verde.
      }
    }

//    return 0;
}
  /*Init();
  SendString((unsigned char*)"Hello World\r\n", &deviceData);
  for(;;) {
    if (RxBuf_NofElements()!=0) {
      SendString((unsigned char*)"echo: ", &deviceData);
      while (RxBuf_NofElements()!=0) {
        unsigned char ch;

        (void)RxBuf_Get(&ch);
        SendChar(ch, &deviceData);
      }
      SendString((unsigned char*)"\r\n", &deviceData);
    }
  }
}*/
